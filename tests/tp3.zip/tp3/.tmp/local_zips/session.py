"""
session.py — TP3
Gestion de la session HTTP pour résoudre un challenge captcha.

Cycle d'utilisation (cf. main.py) :
    session = Session(url)
    session.prepare_request()   # GET page + capture + solve captcha
    session.submit_request()    # POST formulaire
    while not session.process_response():
        session.prepare_request()
        session.submit_request()
    flag = session.get_flag()
"""

import os
import re
import logging
import requests

from src.tp3.utils.captcha import Captcha

logger = logging.getLogger("TP3")

# ---------------------------------------------------------------------------
# Patterns de détection dans la réponse
# ---------------------------------------------------------------------------

_FLAG_PATTERNS = [
    re.compile(r"FLAG\{([^}]+)\}", re.IGNORECASE),
    re.compile(r"ESGI\{([^}]+)\}", re.IGNORECASE),
    re.compile(r"CTF\{([^}]+)\}", re.IGNORECASE),
    re.compile(r'class=["\']flag["\'][^>]*>\s*([^<]+)\s*<', re.IGNORECASE),
    re.compile(r"flag\s*[=:]\s*([A-Za-z0-9_\-]{6,})", re.IGNORECASE),
]

_ERROR_PATTERNS = [
    re.compile(r"incorrect", re.IGNORECASE),
    re.compile(r"wrong", re.IGNORECASE),
    re.compile(r"invalid", re.IGNORECASE),
    re.compile(r"erreur", re.IGNORECASE),
    re.compile(r"mauvais", re.IGNORECASE),
    re.compile(r"captcha.*(?:fail|error|ko)", re.IGNORECASE),
    re.compile(r"try again", re.IGNORECASE),
]


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------

class Session:
    """
    Gère un cycle complet GET → résolution captcha → POST → validation.

    Attributs publics :
        url           -- URL du challenge
        captcha_value -- réponse au captcha (remplie par prepare_request)
        flag_value    -- valeur du token caché du formulaire
        valid_flag    -- flag obtenu après succès (rempli par process_response)
    """

    def __init__(self, url: str):
        self.url: str = url
        self.captcha_value: str = ""
        self.flag_value: str = ""
        self.valid_flag: str = ""

        self._http = requests.Session()
        self._response: requests.Response | None = None
        self._form_fields: dict = {}
        self._form_action: str = url
        self._form_method: str = "post"

    # ------------------------------------------------------------------
    # prepare_request — GET + parse + solve captcha
    # ------------------------------------------------------------------

    def prepare_request(self) -> None:
        """
        1. Crée un Captcha avec la session HTTP partagée
        2. capture() : GET la page, extrait le formulaire et l'image
        3. solve()   : résout le captcha (mock ou saisie manuelle)
        4. Stocke captcha_value, flag_value et les champs du formulaire
        """
        captcha = Captcha(self.url, http_session=self._http)
        captcha.capture()

        # Récupérer les champs du formulaire depuis le Captcha
        self._form_fields = dict(captcha.form_fields)
        self._form_action = captcha.form_action or self.url
        self._form_method = captcha.form_method

        # Résoudre le captcha
        captcha.solve()
        self.captcha_value = captcha.get_value()

        # flag_value = valeur du premier champ caché (token de session côté serveur)
        # On cherche d'abord un champ nommé "flag", sinon on prend le premier dispo
        self.flag_value = (
            self._form_fields.get("flag")
            or self._form_fields.get("token")
            or self._form_fields.get("csrf_token")
            or next(iter(self._form_fields.values()), "")
        )

        logger.debug(
            f"[prepare] captcha_value={self.captcha_value!r} "
            f"flag_value={self.flag_value!r}"
        )
        logger.debug(f"[prepare] form_fields={self._form_fields}")
        logger.debug(f"[prepare] form_action={self._form_action!r} method={self._form_method!r}")

    # ------------------------------------------------------------------
    # submit_request — POST le formulaire
    # ------------------------------------------------------------------

    def submit_request(self) -> None:
        """
        Envoie le formulaire avec :
          - tous les champs cachés extraits lors du GET
          - la valeur résolue du captcha
        """
        if not self.captcha_value:
            logger.warning("[submit] captcha_value vide — prepare_request() appelé ?")

        data = dict(self._form_fields)
        data["captcha"] = self.captcha_value

        headers = {
            "Referer": self.url,
            "Content-Type": "application/x-www-form-urlencoded",
        }

        logger.debug(f"[submit] {self._form_method.upper()} {self._form_action}")
        logger.debug(f"[submit] data envoyée: {data}")

        try:
            if self._form_method == "post":
                self._response = self._http.post(
                    self._form_action, data=data, headers=headers, timeout=15
                )
            else:
                self._response = self._http.get(
                    self._form_action, params=data, headers=headers, timeout=15
                )
        except requests.exceptions.RequestException as exc:
            logger.error(f"[submit] Erreur réseau : {exc}")
            self._response = None
            return

        logger.debug(
            f"[submit] réponse: status={self._response.status_code} "
            f"taille={len(self._response.text)} | cookies={dict(self._http.cookies)}"
        )

        if os.getenv("DEBUG", "0") == "1":
            logger.debug(f"[submit] corps (500c): {self._response.text[:500]}")

    # ------------------------------------------------------------------
    # process_response — analyse la réponse
    # ------------------------------------------------------------------

    def process_response(self) -> bool:
        """
        Analyse la réponse HTTP.

        Retourne True  si le flag a été trouvé (fin du challenge).
        Retourne False si le captcha est incorrect ou la réponse ambiguë
                       (le caller devra recommencer le cycle).
        """
        if self._response is None:
            logger.warning("[process] Pas de réponse disponible.")
            return False

        body = self._response.text
        logger.debug(f"[process] status={self._response.status_code} taille={len(body)}")

        # --- Chercher le flag ---
        for pattern in _FLAG_PATTERNS:
            m = pattern.search(body)
            if m:
                self.valid_flag = m.group(1) if m.lastindex else m.group(0)
                logger.info(f"[process] ✓ Flag trouvé : {self.valid_flag}")
                return True

        # --- Chercher un message d'erreur ---
        for pattern in _ERROR_PATTERNS:
            if pattern.search(body):
                logger.info("[process] ✗ Captcha incorrect, nouvelle tentative...")
                return False

        # --- Cas ambigu : pas de flag, pas d'erreur explicite ---
        logger.warning("[process] Réponse ambiguë — ni flag ni erreur détectés.")
        logger.debug(f"[process] corps (300c): {body[:300]}")
        return False

    # ------------------------------------------------------------------
    # get_flag
    # ------------------------------------------------------------------

    def get_flag(self) -> str:
        """Retourne le flag validé (après process_response() == True)."""
        return self.valid_flag
