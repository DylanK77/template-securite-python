"""
Tests unitaires pour Session (TP3).
Toutes les interactions réseau sont mockées.
"""

import os
from unittest.mock import MagicMock, patch

from src.tp3.utils.session import Session, _FLAG_PATTERNS, _ERROR_PATTERNS


# HTML de référence utilisé dans plusieurs tests
_SAMPLE_HTML = """
<form action="http://31.220.95.27:9002/captcha1/check" method="POST">
    <input type="hidden" name="flag" value="secret_token_xyz">
    <input type="text" name="captcha" value="">
    <img src="/captcha_img.png" alt="captcha">
</form>
"""

_SUCCESS_HTML = """
<html><body>
<p>Bravo ! Voici votre flag : FLAG{tp3_success_42}</p>
</body></html>
"""

_FAILURE_HTML = """
<html><body>
<p>Captcha incorrect, veuillez réessayer.</p>
</body></html>
"""


# ---------------------------------------------------------------------------
# Initialisation
# ---------------------------------------------------------------------------

def test_session_init():
    url = "http://example.com/captcha"
    session = Session(url)
    assert session.url == url
    assert session.captcha_value == ""
    assert session.flag_value == ""
    assert session.valid_flag == ""


# ---------------------------------------------------------------------------
# prepare_request()
# ---------------------------------------------------------------------------

def _make_mock_http(html: str = _SAMPLE_HTML) -> MagicMock:
    """Fabrique une requests.Session mockée qui retourne le HTML donné."""
    mock = MagicMock()
    mock.get.return_value.status_code = 200
    mock.get.return_value.text = html
    mock.get.return_value.content = b"\x89PNG fake"
    mock.get.return_value.raise_for_status = MagicMock()
    mock.cookies = {}
    return mock


@patch.dict(os.environ, {"CAPTCHA_MODE": "mock", "MOCK_CAPTCHA_VALUE": "mock_answer"})
def test_prepare_request_sets_fields():
    """prepare_request() remplit captcha_value, flag_value et form_fields."""
    session = Session("http://example.com/captcha1/")
    session._http = _make_mock_http()
    session.prepare_request()
    assert session.captcha_value == "mock_answer"
    assert session.flag_value == "secret_token_xyz"
    assert session._form_fields.get("flag") == "secret_token_xyz"
    assert "captcha" not in session._form_fields


@patch.dict(os.environ, {"CAPTCHA_MODE": "mock", "MOCK_CAPTCHA_VALUE": "mock_answer"})
def test_prepare_request_no_http(monkeypatch):
    """Sans réseau réel, la session se prépare sans planter."""
    session = Session("http://example.com/captcha")
    # On ne remplace pas _http → le Captcha recevra la vraie session requests
    # mais le réseau est inaccessible → on patch requests.Session.get
    with patch("requests.Session.get", side_effect=Exception("no network")):
        try:
            session.prepare_request()
        except Exception:
            pass
    # Pas de crash non géré — OK


# ---------------------------------------------------------------------------
# submit_request()
# ---------------------------------------------------------------------------

@patch.dict(os.environ, {"CAPTCHA_MODE": "mock", "MOCK_CAPTCHA_VALUE": "mock_answer"})
def test_submit_request_posts_correct_data():
    """submit_request() envoie bien le captcha et le token caché."""
    session = Session("http://example.com/captcha1/")
    session._http = _make_mock_http()
    session.prepare_request()

    # Mock de la réponse POST
    post_mock = MagicMock()
    post_mock.status_code = 200
    post_mock.text = _FAILURE_HTML
    session._http.post.return_value = post_mock

    session.submit_request()

    # Vérifier que le POST a bien été appelé
    session._http.post.assert_called_once()
    call_kwargs = session._http.post.call_args
    sent_data = call_kwargs[1].get("data") or call_kwargs[0][1]
    assert sent_data.get("captcha") == "mock_answer"
    assert sent_data.get("flag") == "secret_token_xyz"


def test_submit_request_no_crash_on_network_error():
    """submit_request() ne plante pas sur erreur réseau."""
    import requests as req
    session = Session("http://unreachable.invalid/captcha")
    session.captcha_value = "test"
    session._form_action = "http://unreachable.invalid/captcha"
    with patch.object(session._http, "post", side_effect=req.exceptions.ConnectionError("unreachable")):
        session.submit_request()  # ne doit pas lever
    assert session._response is None


# ---------------------------------------------------------------------------
# process_response()
# ---------------------------------------------------------------------------

def test_process_response_no_response():
    """Sans réponse, process_response() retourne False."""
    session = Session("http://example.com/captcha")
    result = session.process_response()
    assert result is False


def test_process_response_flag_found():
    """FLAG{...} dans le corps → retourne True et stocke le flag."""
    session = Session("http://example.com/captcha")
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.text = _SUCCESS_HTML
    session._response = mock_resp
    result = session.process_response()
    assert result is True
    assert session.valid_flag == "tp3_success_42"


def test_process_response_captcha_error():
    """Message d'erreur → retourne False."""
    session = Session("http://example.com/captcha")
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.text = _FAILURE_HTML
    session._response = mock_resp
    result = session.process_response()
    assert result is False
    assert session.valid_flag == ""


def test_process_response_ambiguous():
    """Corps sans flag ni erreur → retourne False."""
    session = Session("http://example.com/captcha")
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.text = "<html><body>En cours de traitement...</body></html>"
    session._response = mock_resp
    result = session.process_response()
    assert result is False


# ---------------------------------------------------------------------------
# Patterns de détection
# ---------------------------------------------------------------------------

def test_flag_patterns_match_variants():
    """Les patterns FLAG/ESGI/CTF sont bien reconnus."""
    import re
    cases = [
        ("FLAG{hello_world}", "hello_world"),
        ("ESGI{my_flag_42}", "my_flag_42"),
        ("CTF{secret}", "secret"),
    ]
    for text, expected in cases:
        matched = any(p.search(text) for p in _FLAG_PATTERNS)
        assert matched, f"Pattern non reconnu pour: {text}"


def test_error_patterns_match():
    """Les patterns d'erreur sont bien reconnus."""
    import re
    cases = ["Captcha incorrect", "Wrong answer", "Invalid captcha", "Erreur"]
    for text in cases:
        matched = any(p.search(text) for p in _ERROR_PATTERNS)
        assert matched, f"Pattern d'erreur non reconnu pour: {text}"


# ---------------------------------------------------------------------------
# get_flag()
# ---------------------------------------------------------------------------

def test_get_flag():
    session = Session("http://example.com/captcha")
    session.valid_flag = "FLAG123"
    assert session.get_flag() == "FLAG123"


def test_get_flag_empty_before_success():
    session = Session("http://example.com/captcha")
    assert session.get_flag() == ""
