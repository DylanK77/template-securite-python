"""
captcha.py — TP3
Gestion de la capture et de la résolution du captcha.

Modes disponibles (variable d'environnement CAPTCHA_MODE) :
  - "manual"  : affiche l'image et demande une saisie console (défaut)
  - "mock"    : utilise MOCK_CAPTCHA_VALUE sans interaction (tests)
"""

import os
import subprocess
import tempfile
import logging
from html.parser import HTMLParser
from urllib.parse import urljoin

logger = logging.getLogger("TP3")


# ---------------------------------------------------------------------------
# Parser HTML minimal — extrait formulaire + image captcha
# ---------------------------------------------------------------------------

class _FormParser(HTMLParser):
    """Extrait action/method du <form>, les <input> et l'image captcha."""

    def __init__(self):
        super().__init__()
        self.inputs: dict[str, str] = {}
        self.form_action: str = ""
        self.form_method: str = "post"
        self.captcha_img_src: str = ""

    def handle_starttag(self, tag: str, attrs: list) -> None:
        d = dict(attrs)
        if tag == "form":
            self.form_action = d.get("action", "")
            self.form_method = d.get("method", "post").lower()
        elif tag == "input":
            name = d.get("name", "")
            if name:
                self.inputs[name] = d.get("value", "")
        elif tag == "img":
            src = d.get("src", "")
            alt = d.get("alt", "").lower()
            cls = d.get("class", "").lower()
            if "captcha" in src.lower() or "captcha" in alt or "captcha" in cls:
                self.captcha_img_src = src


# ---------------------------------------------------------------------------
# Classe principale
# ---------------------------------------------------------------------------

class Captcha:
    """
    Représente un captcha d'une page web.

    Attributs publics :
        url         -- URL de la page contenant le captcha
        image       -- chemin local vers l'image téléchargée
        value       -- réponse saisie ou simulée
        form_fields -- champs cachés du formulaire (hors champ captcha)
        form_action -- action du formulaire
        form_method -- méthode HTTP du formulaire
    """

    def __init__(self, url: str, http_session=None):
        self.url: str = url
        self.image: str = ""
        self.value: str = ""
        self.form_fields: dict = {}
        self.form_action: str = ""
        self.form_method: str = "post"
        self._http = http_session

    # ------------------------------------------------------------------
    # capture()
    # ------------------------------------------------------------------

    def capture(self) -> None:
        """
        GET la page, parse le HTML pour extraire les champs du formulaire
        et l'URL de l'image captcha. Télécharge l'image localement.
        Sans session HTTP (tests) : retourne immédiatement.
        """
        if self._http is None:
            logger.debug("capture() — pas de session HTTP, mode passif.")
            return

        logger.debug(f"[capture] GET {self.url}")
        resp = self._http.get(self.url, timeout=10)
        resp.raise_for_status()
        logger.debug(
            f"[capture] status={resp.status_code} | cookies={dict(self._http.cookies)}"
        )

        parser = _FormParser()
        parser.feed(resp.text)

        captcha_field_names = {"captcha", "captcha_value", "answer", "code"}
        self.form_fields = {
            k: v for k, v in parser.inputs.items()
            if k.lower() not in captcha_field_names
        }
        self.form_action = parser.form_action or self.url
        self.form_method = parser.form_method

        logger.debug(f"[capture] form_action={self.form_action!r} method={self.form_method!r}")
        logger.debug(f"[capture] hidden fields={self.form_fields}")
        logger.debug(f"[capture] captcha img src={parser.captcha_img_src!r}")

        if parser.captcha_img_src:
            self._download_captcha_image(parser.captcha_img_src)
        else:
            logger.warning("[capture] Aucune image captcha détectée dans le HTML.")

    def _download_captcha_image(self, src: str) -> None:
        """Télécharge l'image captcha dans un fichier temporaire."""
        img_url = urljoin(self.url, src)
        logger.debug(f"[capture] téléchargement image: {img_url}")

        img_resp = self._http.get(img_url, timeout=10)
        img_resp.raise_for_status()

        ext = os.path.splitext(src.split("?")[0])[1] or ".png"
        tmp = tempfile.NamedTemporaryFile(
            suffix=ext, delete=False, prefix="captcha_tp3_"
        )
        tmp.write(img_resp.content)
        tmp.close()
        self.image = tmp.name
        logger.info(f"[capture] image sauvegardée : {self.image}")

    # ------------------------------------------------------------------
    # solve()
    # ------------------------------------------------------------------

    def solve(self) -> None:
        """
        Résout le captcha.

        CAPTCHA_MODE=mock  → valeur issue de MOCK_CAPTCHA_VALUE (défaut "FIXME")
        CAPTCHA_MODE=manual → ouvre l'image, attend une saisie console
        """
        mode = os.getenv("CAPTCHA_MODE", "manual")

        if mode == "mock":
            self.value = os.getenv("MOCK_CAPTCHA_VALUE", "FIXME")
            logger.debug(f"[solve] mode MOCK — valeur: {self.value!r}")
            return

        # Mode manuel
        if self.image and os.path.exists(self.image):
            self._open_image(self.image)
            logger.info(f"[solve] image captcha : {self.image}")
        else:
            logger.warning("[solve] Aucune image locale disponible.")

        self.value = input(">>> Saisir la valeur du captcha : ").strip()
        logger.debug(f"[solve] valeur saisie: {self.value!r}")

    def _open_image(self, path: str) -> None:
        """Ouvre l'image avec le viewer système (best-effort)."""
        try:
            if os.name == "nt":
                os.startfile(path)  # type: ignore
            else:
                viewer = "open" if os.uname().sysname == "Darwin" else "xdg-open"
                subprocess.call([viewer, path], stderr=subprocess.DEVNULL)
        except Exception as exc:
            logger.debug(f"[solve] Impossible d'ouvrir l'image: {exc}")

    # ------------------------------------------------------------------
    # Accesseur
    # ------------------------------------------------------------------

    def get_value(self) -> str:
        """Retourne la valeur du captcha (après solve())."""
        return self.value
